public class Alugado {

    private String dataAlugado;
    private String dataDevolucao;
    private boolean disponivel;

    public Alugado(String dataAlugado, String dataDevolucao, boolean disponivel) {
        this.dataAlugado = dataAlugado;
        this.dataDevolucao = dataDevolucao;
        this.disponivel = disponivel;
    }

    public String getDataAlugado() {
        return dataAlugado;
    }

    public void setDataAlugado(String dataAlugado) {
        this.dataAlugado = dataAlugado;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
}
