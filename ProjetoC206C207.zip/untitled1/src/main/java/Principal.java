import java.util.*;
public class Principal {

    public static Cliente Popula(Cliente c) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Informe o nome do cliente: ");
        c.setNome(scan.nextLine());

        System.out.println();
        return c;
    }

    public static Filme Popula(Filme f) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Informe o titulo do filme: ");
        f.setTitulo(scan.nextLine());

        System.out.println();
        return f;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int op = 1;
        boolean flag = true;
        Filme f = new Filme();
        ClienteDAO c2 = new ClienteDAO();
        AlugadoDAO a2 = new AlugadoDAO();


        while (flag) {
            System.out.println("1 - Cadastro Cliente");
            System.out.println("2 - Locação Filme");
            System.out.println("3 - Devolução Filme");
            System.out.println("4 - Filmes Diponiveis");
            System.out.println("5 - Sair");

            op = scan.nextInt();

            switch (op) {
                case 1:
                    String nome = scan.nextLine();
                    int Cpf = scan.nextInt();
                    String endereco = scan.nextLine();
                    Cliente c = new Cliente(nome, Cpf, endereco);
                    c2.inserirCliente(c);

                    break;

                case 2:
                    String dataAlugado = scan.nextLine();
                    String dataDeVolucao = scan.nextLine();
                    boolean disponivel = scan.nextBoolean();
                    Alugado a = new Alugado(dataAlugado, dataDeVolucao, disponivel);
                    a2.inserirAlugado(a);
                    break;

                case 3:
                    int codigo = scan.nextInt();
                    a2.deletarAlugado(codigo);
                    break;
                case 4:



                case 5:
                    flag = false;


            }
        }
    }
}




