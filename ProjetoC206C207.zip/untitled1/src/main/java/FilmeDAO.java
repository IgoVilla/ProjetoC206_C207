import java.sql.SQLException;

public class FilmeDAO extends ConnectionDAO {
    boolean aprovado = false;

    //DAO -DATA ACCESS OBJECT
    public boolean inserirFilme(Filme filme) {
        connectToDB();
        String sql = "INSERT INTO filme (nome, genero, codigo) values(?,?,?)";
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, filme.getNome());
            pst.setString(2, filme.getGenero());
            pst.setInt(3, filme.getCodigo());

            pst.execute();
            aprovado = true;
        } catch (SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            aprovado = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }

        return aprovado;
    }
}
